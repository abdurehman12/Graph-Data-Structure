
class StackNode<T> {
    T info;
    StackNode<T> next;
    public StackNode(T data){
        info = data;
    }
}
