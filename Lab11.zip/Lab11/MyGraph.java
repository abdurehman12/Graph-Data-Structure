
public class MyGraph {
    vertex[] adjList;
    int count;
    MyGraph(int s){
        adjList=new vertex[s];
        count=-1;
    }
    public void AddVertex(String n, int a){ // add person name and age…
        vertex ver = new vertex(n,a);
        if(count==adjList.length-1){
            System.out.println("List is full");
        }
        else if(FindVertex(n)==null){
            count++; 
            adjList[count]=ver;
        }
        else{
            System.out.println("Vertex already present in adjacency list");
        }
    }
    public void AddEdge(String n1,String n2) {// add an edge between two person 
        vertex v1 =FindVertex(n1);
        vertex v2 =FindVertex(n2);
        if(v1!=null && v2!=null){
            if(v1.friendsList.find(v2)==false && v2.friendsList.find(v1)==false){
                v1.friendsList.Insert(v2);
                v2.friendsList.Insert(v1);
            }
            else{
            System.out.println("This relation already exists");                 
            }
        }
        else{
            System.out.println("Please add the vertices to the list before adding a relation between them"); 
        }
    }
    public void DFS(MyGraph G, String n) { // print all person in DFS sequence,use stack that you implement earlier where G is graph and s is source vertex
        vertex s = G.FindVertex(n);
        if(G.count!=-1 && G.FindVertex(n)!=null){
            LinkedListStack<vertex> stack = new LinkedListStack<>();
            Boolean[] Visited = new Boolean[G.count+1];
            for(int i=0; i<Visited.length; i++){
                Visited[i]=false;
            }
            stack.PUSH(s);
            Visited[G.FindIndex(n)]=true;
            System.out.println(s);
            int unvisited = count;
            vertex v;
            vertex w;
            while(unvisited>0){
                while(!stack.isEmpty()){
                    v = stack.POP();
                    w=null;
                    for(int i=0; i<Visited.length;i++){
                        if(v.friendsList.find(G.adjList[i]) && Visited[i]==false){
                            w= G.adjList[i];
                            break;
                        }
                    }
                    if(w!=null){
                        stack.PUSH(w);
                        Visited[G.FindIndex(w.name)]=true;
                        System.out.println( w);
                        unvisited--;
                    }
                    else{
                        stack.POP();
                    }
                }
                v=null;
                for(int i=0; i<Visited.length;i++){
                    if(Visited[i]==false){
                        v=G.adjList[i];
                        break;
                    }
                }
                if(v!=null){
                    stack.PUSH(v);
                    Visited[G.FindIndex(v.name)]=true;
                    unvisited--;
                    System.out.println(v);
                }
                else{
                    break;
                }
            }
        }
    }
    public void deleteVertex(String n){ // delete a person
        vertex v1= FindVertex(n);
        if(v1!=null){
            for(int i=0;i<=count;i++){
                if(adjList[i].name.equals(n)){
                    adjList[i]=null;
                }
                else{
                        adjList[i].friendsList.delete(n);
                } 
            }
            AdjustList();
        }
        else{
            System.out.println("This vertex is not present in list");             
        }
    }
    public void deleteEdge(String n1,String n2){ // delete friend’s relation by removing an edge between two person 
        vertex v1 =FindVertex(n1);
        vertex v2 =FindVertex(n2);
        if(v1!=null && v2!=null){
            v1.friendsList.delete(n2);
            v2.friendsList.delete(n1);
        }
        else{
            System.out.println("Please add the vertices to the list before deleting the relation between them"); 
        }
    }
    public vertex FindVertex(String n){ // find a person 
        for(int i=0; i<=count;i++){
            if(adjList[i].name.equalsIgnoreCase(n)){
                return adjList[i];
            }
        }
        return null;
    }
    public int FindIndex(String n){ // find a person 
        for(int i=0; i<=count;i++){
            if(adjList[i].name.equalsIgnoreCase(n)){
                return i;
            }
        }
        return -1;
    }
    @Override
    public String toString(){ // list all person and their friend’s relationship 
        String s="";
        for(int i=0;i<=count;i++){
            s+=adjList[i].name+"("+ adjList[i].age+ ") is friends with: "+adjList[i].friendsList+"\n";
        }
        return s;
    }

    private void AdjustList(){
        int i=0;
        for(; i<=count;i++){
            if(adjList[i]==null){
                break;
            }
        }
        if(i!=count){
            for(;i<=count-1;i++){
                adjList[i]=adjList[i+1];
            }
        }
        count--;
    }
}

