
public class vertex {
    String name;
    int age;
    LinkedList friendsList=new LinkedList();
    
    vertex(String d, int a){
        name=d;
        age=a;
    }
    public String toString(){
        return name+"("+age+")";
    }
}

