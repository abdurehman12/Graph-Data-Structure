
public class Node {
    vertex v;
    Node next;
    Node(vertex ver){
        v=ver;
    }
    @Override
    public String toString(){
        return v.name +"("+v.age+")";
    }
}
